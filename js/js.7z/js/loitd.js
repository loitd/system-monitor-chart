/////////////////////////////
//JS created by Loitd()
/////////////////////////////

$(document).ready(function() {
	var xbase_url = location.protocol + '//' + window.location.host + '/CDVChart/index.php/hchart/';
	var xjson1_url = xbase_url + 'cdv_stats';
	jQuery.getJSON(xjson1_url, function(data){
		//console.log(data.STT);
		jQuery("#status").html("Lượng sim online: " + data.STT);
	})
	//alert(xdata["STT"]);

});